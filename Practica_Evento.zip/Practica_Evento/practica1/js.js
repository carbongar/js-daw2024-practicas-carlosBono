document.addEventListener("keydown", function (event) {
    if (event.altKey && event.code === "F12") {
        document.getElementById("imagen").style.backgroundImage = "url('lonsez.jpg')"; 
    }
});
