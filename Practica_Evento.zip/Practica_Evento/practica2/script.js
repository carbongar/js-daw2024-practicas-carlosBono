const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const errorEmail = document.getElementById("error-email");
const errorPassword = document.getElementById("error-password");
const btn = document.getElementById("boton-enviar");

function form() {
    const emailValido = /^[^@]+@[^@]+\.[a-zA-Z]{2,}$/.test(emailInput.value);                   //Valida que el email sea igual que el formato
    const passwordValido = passwordInput.value.length >= 8 && passwordInput.value.length <= 10; //Valida que el password sea mayor o igual a 8 y menor o igual a 10

    btn.disabled = !(emailValido && passwordValido);                                            //Desactivamos si alguno de los anteriores .value nos da false, si nos dan los dos true lo activamos 
}

emailInput.addEventListener("blur", () => {                                                    //usamos blur, es decir, cuando perdemos el foco del input ocurre lo siguiente
    const emailValido = /^[^@]+@[^@]+\.[a-zA-Z]{2,}$/.test(emailInput.value);                   //Si el password es valido ocurre display:none para que no salgo, inline, para que salga el error
    errorEmail.style.display = emailValido ? "none" : "inline";                                 ////Llamamos sa la funcion de formulario 
    form();
});

passwordInput.addEventListener("blur", () => {                                                  //usamos blur, es decir, cuando perdemos el foco del input ocurre lo siguiente
    const passwordValido = passwordInput.value.length >= 8 && passwordInput.value.length <= 10;
    errorPassword.style.display = passwordValido ? "none" : "inline";                           //Si el password es valido ocurre display:none para que no salgo, inline, para que salga el error
    form();                                                                                     //Llamamos sa la funcion de formulario 
});

emailInput.addEventListener("input", form);               
passwordInput.addEventListener("input", form);
