function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  async function startCountdown(seconds) {
    let counter = seconds;
    const countdownDiv = document.getElementById('countdown');
  
    while (counter >= 0) {
      countdownDiv.innerText = `Cuenta atrás: ${counter}`;
      await timeout(1000);
      counter--;
    }
  
    document.getElementById('notification').style.display = 'block';
  }
  
  startCountdown(5);
  