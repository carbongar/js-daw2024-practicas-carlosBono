const video = document.getElementById('video');
const videoInfo = document.getElementById('video-info');

video.addEventListener('click', () => {
  if (video.paused) {
    video.play();
  } else {
    video.pause();
  }
});

video.addEventListener('contextmenu', (event) => {
  event.preventDefault();
  const minutes = Math.floor(video.duration / 60);
  const seconds = Math.floor(video.duration % 60);
  videoInfo.innerText = `Duración total del video: ${minutes} minutos y ${seconds} segundos`;
});
