// Función para establecer una cookie
function setCookie(name, value, days) {
    const date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    document.cookie = name + "=" + value + ";expires=" + date.toUTCString() + ";path=/";
}

// Función para obtener una cookie
function getCookie(name) {
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i].trim();
        if (cookie.indexOf(name + "=") === 0) {
            return cookie.substring((name + "=").length);
        }
    }
    return null;
}

// Cargar 
function cargar() {
    const contentDiv = document.getElementById('content');
    const userName = getCookie('userName');
    if (userName) {
        contentDiv.innerHTML = "<h1>Bienvenido, " + userName + "!</h1>";
    } else {
        contentDiv.innerHTML = 
            '<label for="name">Ingresa tu nombre:</label>' +
            '<input type="text" id="name">' +
            '<button onclick="guardarNombre()">Guardar</button>';
    }
}

// Función para guardar el nombre en una cookie
function guardarNombre() {
    const nameInput = document.getElementById('name');
    const name = nameInput.value.trim();
    if (name) {
        setCookie('userName', name, 7);
        location.reload();
    }
}

cargar();
