const words = ["monitor", "teclado", "raton", "maquina", "virtual", "ordenador", "javascript", "uno", "navidad", "oceano"];

//Lista de palabras
function displayList(words) {
    const list = document.getElementById('wordList');
    list.innerHTML = ""; 
    words.forEach(word => {
        const li = document.createElement('li');
        li.textContent = word;
        list.appendChild(li);
    });
}

displayList(words);

setTimeout(() => {
    if (confirm("¿Quieres que la lista se ordene alfabéticamente?")) {
        words.sort((a, b) => a.localeCompare(b)); 
        displayList(words); 
    }
}, 3000);
