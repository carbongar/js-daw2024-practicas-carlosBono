function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  async function CuentaAtras(seconds) {
    let counter = seconds;
    const CuentaAtrasDiv = document.getElementById('CuentaAtras');
  
    while (counter >= 0) {
      CuentaAtrasDiv.innerText = `Cuenta atrás: ${counter}`;
      await timeout(1000);
      counter--;
    }
  
    document.getElementById('notification').style.display = 'block';
  }
  
  CuentaAtras(5);
  