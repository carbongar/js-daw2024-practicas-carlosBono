document.getElementById('enviar').addEventListener('click', async function() {
    const retraso = document.getElementById('retraso').value;
    const numeroUsuario = document.getElementById('numeroUsuario').value;
    try {
        const response = await fetch(`https://reqres.in/api/users/${numeroUsuario}?retraso=${retraso}`);
        if (!response.ok) {
            throw new Error(`Error ${response.status}: Usuario no encontrado`);
        }
        const data = await response.json();
        const usuario = data.data;
        document.getElementById('id').textContent = usuario.id;
        document.getElementById('email').textContent = usuario.email;

        const postResponse = await fetch('https://httpbin.org/post', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(usuario)
        });
        const postData = await postResponse.json();
        document.getElementById('nombre').textContent = postData.json.first_name;
        document.getElementById('estado').textContent = postResponse.status;
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('estado').textContent = error.message;
    }
});
