window.onload = function() {
    fetch('https://fakerapi.it/api/v2/persons?_quantity=1')
        .then(respuesta => respuesta.json())
        .then(contenido => {
            const persona = contenido.data[0];
            document.getElementById('nombre').textContent = persona.firstname;
            document.getElementById('apellidos').textContent = persona.lastname;
            document.getElementById('email').textContent = persona.email;
            document.getElementById('direccion').textContent = persona.address.street;
            document.getElementById('pais').textContent = persona.address.country;
        })
        .catch(error => console.error('Ha ocurrido un error:', error));
};
