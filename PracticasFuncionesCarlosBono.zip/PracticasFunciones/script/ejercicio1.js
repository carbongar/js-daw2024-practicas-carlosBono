//Funcion1
function procesarPalabras(palabras) {
    const palabrasUnicas = [...new Set(palabras)];
    return palabrasUnicas.sort((a, b) => b.localeCompare(a, 'es'));
}
