//Funcion2

function contarPalabras(palabras) {
    const mapaFrecuencias = new Map();

    palabras.forEach(function (palabra) {
        if (mapaFrecuencias.has(palabra)) {
            mapaFrecuencias.set(palabra, mapaFrecuencias.get(palabra) + 1);
        } else {
            mapaFrecuencias.set(palabra, 1);
        }
    });

    return mapaFrecuencias;
}