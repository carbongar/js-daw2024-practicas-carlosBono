document.getElementById('contar').addEventListener('click', function () {
    var palabras = [];
    var input;

    do {
        input = prompt("Introduce una palabra, para finalizar pulsa el boton cancelar");
        if (input !== null && input.trim() !== "") {
            palabras.push(input.trim());
        }
    } while (input !== null && input.trim() !== "");

    var resultadoDiv = document.getElementById('resultado');

    if (palabras.length > 0) {
        var mapaFrecuencias = contarPalabras(palabras);

        var resultado = "";
        mapaFrecuencias.forEach(function (valor, clave) {
            resultado += "<li>" + clave + ": " + valor + "</li>";
        });
        resultado += "</ul>";
        resultadoDiv.innerHTML = resultado;
    } else {
        resultadoDiv.innerHTML = "No se han introducido palabras";
    }
});
