Array.prototype.mediaAritmetica = function() {

    //Valido que el array no este vacio
    if (this.length === 0) {
        throw new Error("El array esta vacio");
    }
    //Usamos reduce para acumular los numeros del array
    const suma = this.reduce((acumulador, elemento) => acumulador + elemento, 0);

    //Divido la suma por la cantidad del array
    return suma / this.length;
};

try { //Creo 3 arrays, 2 con numeros y otro vacio, entonces se suman todos los numeros de los arrays y si saca la media
    const array1 = [1, 7, 33, 82, 312];
    const array2 = [2, 34, 102];
    const array3 = []; 

    console.log("Media 1 : " + array1.mediaAritmetica());
    console.log("Media 2: " + array2.mediaAritmetica());

    console.log("Media 3: " + array3.mediaAritmetica());

} catch (error) {
    console.error("Error: " + error.message);
}
