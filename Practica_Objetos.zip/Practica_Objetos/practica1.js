function Rectangulo(width, height) {
    // Validacion
    if (typeof width !== 'number' || width <= 0) {
        width = 1;
    }
    if (typeof height !== 'number' || height <= 0) {
        height = 1;
    }

    this.width = width;
    this.height = height;

    //Método cambiarDimensiones
    this.cambiarDimensiones = function(newWidth, newHeight) { 
        if (typeof newWidth === 'number' && newWidth > 0) {
            this.width = newWidth;
        }
        if (typeof newHeight === 'number' && newHeight > 0) {
            this.height = newHeight;
        }
    };

    //Método calcularArea
    this.calcularArea = function() {
        return this.width * this.height;
    };

    //Método copia
    this.copia = function() {
        return new Rectangulo(this.width, this.height);
    };

    //Método comparar:
    this.comparar = function(otroRectangulo) {
        if (!(otroRectangulo instanceof Rectangulo)) {
            throw new Error("El argumento no es un rectángulo válido.");
        }

        const areaActual = this.calcularArea();
        const areaOtro = otroRectangulo.calcularArea();

        if (areaActual > areaOtro) {
            return "mayor";
        } else if (areaActual < areaOtro) {
            return "menor";
        } else {
            return "igual";
        }
    };
}

//Validacion
const rect1 = new Rectangulo(5, 10);
const rect2 = new Rectangulo(7, 3);
const rect3 = new Rectangulo(-4, 0);

rect1.cambiarDimensiones(8, 12);
console.log("Nuevas dimensiones de rect1: " + rect1.width + " x " + rect1.height);

console.log("Área de rect 1: " + rect1.calcularArea());
console.log("Área de rect 2: " + rect2.calcularArea());

const copiaRect1 = rect1.copia();
console.log("Dimensiones de la copia de rect 1: " + copiaRect1.width + " x " + copiaRect1.height);

console.log("Comparación rect 1 y rect 2: " + rect1.comparar(rect2));
console.log("Comparación rect 1 y su copia: " + rect1.comparar(copiaRect1));

console.log("Dimensiones de rect3 por defecto: " + rect3.width + " x " + rect3.height);